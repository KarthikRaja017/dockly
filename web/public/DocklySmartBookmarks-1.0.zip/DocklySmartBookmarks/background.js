chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ bookmarks: [] });
  console.log("Dockly Smart Bookmarks Installed!");
});