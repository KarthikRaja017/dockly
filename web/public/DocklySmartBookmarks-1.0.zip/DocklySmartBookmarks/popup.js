document.addEventListener("DOMContentLoaded", function () {
  const saveBtn = document.getElementById("saveBtn");
  const bookmarkList = document.getElementById("bookmarkList");

  saveBtn.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const page = {
        title: tabs[0].title,
        url: tabs[0].url,
        favicon: `https://www.google.com/s2/favicons?sz=64&domain=${
          new URL(tabs[0].url).hostname
        }`,
      };

      chrome.storage.local.get({ bookmarks: [] }, (data) => {
        const updatedBookmarks = [...data.bookmarks, page];
        chrome.storage.local.set({ bookmarks: updatedBookmarks }, () => {
          showBookmarks();
        });
      });
    });
  });

  function showBookmarks() {
    chrome.storage.local.get({ bookmarks: [] }, (data) => {
      bookmarkList.innerHTML = "";

      data.bookmarks
        .slice()
        .reverse()
        .forEach((bm) => {
          const li = document.createElement("li");
          li.classList.add("bookmark-card");
          li.innerHTML = `
                  <img src="${bm.favicon}" class="favicon" alt="Favicon">
                  <div class="bookmark-info">
                      <p class="bookmark-title">${bm.title}</p>
                      <p class="bookmark-url">${bm.url}</p>
                  </div>
              `;
          li.addEventListener("click", () => {
            window.open(bm.url, "_blank");
          });
          bookmarkList.appendChild(li);
        });
    });
  }

  showBookmarks();
});
