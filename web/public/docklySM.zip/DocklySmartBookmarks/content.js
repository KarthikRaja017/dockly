// Modern content script for Dockly Smart Bookmarks
(() => {
  'use strict';

  // Check if we're on a supported page
  if (
    document.location.protocol === 'chrome:' ||
    document.location.protocol === 'edge:' ||
    document.location.protocol === 'about:'
  ) {
    return;
  }

  // Initialize content script
  function initContentScript() {
    console.log('🔧 Initializing content script on:', document.location.href);

    // Check for existing UID in localStorage
    const uid = localStorage.getItem('uid');

    if (uid) {
      console.log('Found UID in localStorage:', uid);
      // Send UID to background script
      chrome.runtime
        .sendMessage({
          action: 'setUID',
          uid,
        })
        .catch((error) => {
          console.warn('Failed to send UID to background script:', error);
        });
    }

    // Listen for storage changes to sync UID
    window.addEventListener('storage', (e) => {
      if (e.key === 'uid' && e.newValue) {
        console.log('UID updated in localStorage:', e.newValue);
        chrome.runtime
          .sendMessage({
            action: 'setUID',
            uid: e.newValue,
          })
          .catch((error) => {
            console.warn(
              'Failed to send updated UID to background script:',
              error
            );
          });
      }
    });
  }

  // Wait for DOM to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initContentScript);
  } else {
    initContentScript();
  }

  // Add visual feedback for successful bookmark saves (optional)
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'bookmarkSaved') {
      showBookmarkNotification();
    }
  });

  // Show subtle notification when bookmark is saved
  function showBookmarkNotification() {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #0033FF;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(0, 51, 255, 0.3);
      z-index: 10000;
      opacity: 0;
      transform: translateY(-10px);
      transition: all 0.3s ease;
      pointer-events: none;
    `;

    notification.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
        </svg>
        Bookmark saved!
      </div>
    `;

    document.body.appendChild(notification);

    // Animate in
    requestAnimationFrame(() => {
      notification.style.opacity = '1';
      notification.style.transform = 'translateY(0)';
    });

    // Remove after delay
    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transform = 'translateY(-10px)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 2000);
  }
})();
