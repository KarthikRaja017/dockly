// Configuration constants
const CONFIG = {
  PRIMARY_COLOR: '#0033FF',
  SECONDARY_COLOR: '#F8FAFF',
  SUCCESS_COLOR: '#10B981',
  ERROR_COLOR: '#EF4444',
  WARNING_COLOR: '#F59E0B',

  // API URLs
  // API_BASE_URL: 'http://127.0.0.1:5000/server/api',
  // DOCKLY_BASE_URL: 'http://localhost:3000',
  API_BASE_URL: 'https://dockly.onrender.com/server/api',
  DOCKLY_BASE_URL: 'https://docklyme.vercel.app',

  // API Endpoints
  ENDPOINTS: {
    SAVE_BOOKMARK: '/bookmarks/save',
    SAVE_ALL_BOOKMARKS: '/bookmarks/all/save',
    ADD_USER: '/user/add/username',
  },

  // UI Constants - Updated for compact view
  UI: {
    ANIMATION_DURATION: 300,
    SAVE_HIGHLIGHT_DURATION: 1500,
    MAX_BOOKMARKS_DISPLAY: 2, // Changed from 5 to 2 for compact view
  },

  // Blocked protocols for bookmarking
  BLOCKED_PROTOCOLS: ['chrome:', 'edge:', 'about:', 'file:'],
};

// Helper functions
function getApiUrl(endpoint) {
  return CONFIG.API_BASE_URL + CONFIG.ENDPOINTS[endpoint];
}

function getDocklyUrl(username) {
  return `${CONFIG.DOCKLY_BASE_URL}/${username}/bookmarks`;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function truncateUrl(url) {
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname.replace('www.', '');
    // Shorter truncation for compact view
    return domain.length > 25 ? domain.substring(0, 22) + '...' : domain;
  } catch {
    return url.length > 25 ? url.substring(0, 22) + '...' : url;
  }
}

function truncateTitle(title) {
  // Shorter title truncation for compact view
  return title.length > 30 ? title.substring(0, 27) + '...' : title;
}

// Main extension logic
document.addEventListener('DOMContentLoaded', function () {
  const bookmarkList = document.getElementById('bookmarkList');
  const emptyState = document.getElementById('emptyState');
  const syncBtn = document.getElementById('syncBtn');
  const modal = document.getElementById('loginModal');
  const closeBtn = document.getElementById('closeModal');
  const loginForm = document.getElementById('loginForm');
  const usernameInput = document.getElementById('username');
  const errorEl = document.getElementById('error-msg');
  const bookmarkCount = document.querySelector('.bookmark-count');

  // Initialize the extension
  function init() {
    console.log('🚀 Initializing Dockly Smart Bookmarks...');
    showBookmarks();
    updateSyncButtonText();
    addEventListeners();
  }

  // Add all event listeners
  function addEventListeners() {
    syncBtn.addEventListener('click', handleSyncClick);
    closeBtn.addEventListener('click', closeModal);
    loginForm.addEventListener('submit', handleLogin);

    // Close modal on outside click
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal();
      }
    });

    // Close modal on escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.style.display === 'flex') {
        closeModal();
      }
    });
  }

  // Show bookmarks with modern UI handling
  function showBookmarks() {
    console.log('📚 Loading bookmarks...');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError) {
        console.error('Error querying tabs:', chrome.runtime.lastError);
        loadExistingBookmarks();
        return;
      }

      const tab = tabs[0];
      if (!tab || !tab.url) {
        console.warn('No active tab found');
        loadExistingBookmarks();
        return;
      }

      const url = tab.url;
      console.log('Current tab URL:', url);

      // Check if URL can be bookmarked
      if (CONFIG.BLOCKED_PROTOCOLS.some((proto) => url.startsWith(proto))) {
        console.log('URL blocked from bookmarking:', url);
        loadExistingBookmarks();
        return;
      }

      const currentBookmark = createBookmarkObject(tab);
      console.log('Created bookmark object:', currentBookmark);

      chrome.storage.local.get({ bookmarks: [] }, (data) => {
        if (chrome.runtime.lastError) {
          console.error('Error getting bookmarks:', chrome.runtime.lastError);
          showError('Failed to load bookmarks');
          return;
        }

        console.log('Existing bookmarks:', data.bookmarks);
        const exists = data.bookmarks.some(
          (bookmark) => bookmark.url === currentBookmark.url
        );

        if (!exists) {
          const updatedBookmarks = [...data.bookmarks, currentBookmark];
          saveNewBookmark(updatedBookmarks, currentBookmark);
        } else {
          console.log('Bookmark already exists');
          renderBookmarkList(data.bookmarks, false);
        }
      });
    });
  }

  // Load existing bookmarks only
  function loadExistingBookmarks() {
    chrome.storage.local.get({ bookmarks: [] }, (data) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error loading existing bookmarks:',
          chrome.runtime.lastError
        );
        showError('Failed to load bookmarks');
        return;
      }
      renderBookmarkList(data.bookmarks, false);
    });
  }

  // Create bookmark object
  function createBookmarkObject(tab) {
    return {
      id: Date.now().toString(),
      title: tab.title || 'Untitled',
      url: tab.url,
      favicon: `https://www.google.com/s2/favicons?sz=32&domain=${
        new URL(tab.url).hostname
      }`,
      timestamp: Date.now(),
    };
  }

  // Save new bookmark
  function saveNewBookmark(bookmarks, newBookmark) {
    console.log('💾 Saving new bookmark:', newBookmark);

    chrome.storage.local.set({ bookmarks }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error saving bookmark:', chrome.runtime.lastError);
        showError('Failed to save bookmark');
        return;
      }

      console.log('✅ Bookmark saved successfully');
      renderBookmarkList(bookmarks, true);
      syncBookmarkToServer([newBookmark]);
    });
  }

  // Sync bookmark to server
  function syncBookmarkToServer(bookmarks) {
    chrome.storage.local.get('uid', (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error getting UID:', chrome.runtime.lastError);
        return;
      }

      if (result.uid) {
        console.log('🔄 Syncing bookmark to server...');

        fetch(getApiUrl('SAVE_BOOKMARK'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ uid: result.uid, bookmarks }),
        })
          .then((response) => {
            if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
          })
          .then((data) => {
            console.log('✅ Bookmarks synced successfully:', data);
          })
          .catch((error) => {
            console.error('❌ Sync failed:', error);
          });
      } else {
        console.log('No UID found, skipping server sync');
      }
    });
  }

  // Render bookmark list with compact UI
  function renderBookmarkList(bookmarks, justSaved) {
    console.log('🎨 Rendering bookmark list:', bookmarks.length, 'bookmarks');

    bookmarkList.innerHTML = '';

    if (!bookmarks || bookmarks.length === 0) {
      emptyState.style.display = 'block';
      bookmarkCount.textContent = '0';
      return;
    }

    emptyState.style.display = 'none';

    // Show only last 2 bookmarks (most recent first)
    const recentBookmarks = bookmarks
      .slice(-CONFIG.UI.MAX_BOOKMARKS_DISPLAY)
      .reverse();

    bookmarkCount.textContent = bookmarks.length;

    recentBookmarks.forEach((bookmark, index) => {
      const bookmarkEl = createBookmarkElement(
        bookmark,
        index === 0 && justSaved
      );
      bookmarkList.appendChild(bookmarkEl);

      // Add staggered animation
      setTimeout(() => {
        bookmarkEl.classList.add('slide-in');
      }, index * 100);
    });
  }

  // Create compact bookmark element
  function createBookmarkElement(bookmark, shouldHighlight) {
    const div = document.createElement('div');
    div.classList.add('bookmark-card');

    if (shouldHighlight) {
      div.classList.add('bookmark-new');
      setTimeout(
        () => div.classList.remove('bookmark-new'),
        CONFIG.UI.SAVE_HIGHLIGHT_DURATION
      );
    }

    div.innerHTML = `
      <div class="bookmark-favicon">
        <img 
          src="${bookmark.favicon}" 
          alt="Favicon"
          onerror="this.src='https://www.google.com/s2/favicons?sz=32&domain=${
            new URL(bookmark.url).hostname
          }'"
        />
      </div>
      
      <div class="bookmark-info">
        <h3 class="bookmark-title" title="${escapeHtml(bookmark.title)}">
          ${escapeHtml(truncateTitle(bookmark.title))}
        </h3>
        <p class="bookmark-url" title="${escapeHtml(bookmark.url)}">
          ${escapeHtml(truncateUrl(bookmark.url))}
        </p>
      </div>

      <div class="bookmark-action">
        <svg class="bookmark-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
          <polyline points="15,3 21,3 21,9" />
          <line x1="10" y1="14" x2="21" y2="3" />
        </svg>
      </div>

      <div class="bookmark-ripple"></div>
    `;

    div.addEventListener('click', () => openBookmark(bookmark.url));

    // Add ripple effect on click
    div.addEventListener('click', function (e) {
      createRippleEffect(e, this);
    });

    return div;
  }

  // Create ripple effect
  function createRippleEffect(event, element) {
    const ripple = element.querySelector('.bookmark-ripple');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;

    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple-active');

    setTimeout(() => {
      ripple.classList.remove('ripple-active');
    }, 600);
  }

  // Open bookmark in new tab
  function openBookmark(url) {
    console.log('🔗 Opening bookmark:', url);
    chrome.tabs.create({ url }, (tab) => {
      if (chrome.runtime.lastError) {
        console.error('Error opening bookmark:', chrome.runtime.lastError);
        showError('Failed to open bookmark');
      }
    });
  }

  // Handle sync button click
  function handleSyncClick() {
    console.log('🔄 Sync button clicked');

    // Add button animation
    syncBtn.classList.add('animating');
    setTimeout(() => syncBtn.classList.remove('animating'), 600);

    chrome.storage.local.get(['uid', 'username'], (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error getting user data:', chrome.runtime.lastError);
        showError('Failed to get user data');
        return;
      }

      console.log('User data:', result);

      if (result.uid && result.username) {
        const docklyUrl = getDocklyUrl(result.username);
        console.log('Opening Dockly URL:', docklyUrl);
        chrome.tabs.create({ url: docklyUrl });
      } else {
        console.log('No user data found, showing login modal');
        showModal();
      }
    });
  }

  // Handle login form submission
  async function handleLogin(e) {
    e.preventDefault();

    const userName = usernameInput.value.trim();
    if (!userName) {
      showError('Please enter a username');
      return;
    }

    console.log('🔐 Attempting login for:', userName);
    showLoading(true);
    clearError();

    try {
      const response = await fetch(getApiUrl('ADD_USER'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName, isBookmark: true }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Login response:', data);

      if (data.status !== 1 || !data.payload?.userId) {
        showError(
          data.message ||
            'Username not found. Please check your username or register.'
        );
        return;
      }

      const uid = data.payload.userId;
      console.log('✅ Login successful, UID:', uid);

      await saveUserData(uid, userName);
      closeModal();
      updateSyncButtonText();
      syncAllBookmarks(uid);
    } catch (error) {
      console.error('❌ Login error:', error);
      showError('Connection failed. Please try again.');
    } finally {
      showLoading(false);
    }
  }

  // Save user data to storage
  function saveUserData(uid, username) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.set({ uid, username }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error saving user data:', chrome.runtime.lastError);
          reject(chrome.runtime.lastError);
        } else {
          console.log('✅ User data saved:', { uid, username });
          resolve();
        }
      });
    });
  }

  // Sync all bookmarks after login
  function syncAllBookmarks(uid) {
    console.log('🔄 Syncing all bookmarks for UID:', uid);

    chrome.storage.local.get({ bookmarks: [] }, (data) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error getting bookmarks for sync:',
          chrome.runtime.lastError
        );
        return;
      }

      if (data.bookmarks.length > 0) {
        console.log('Syncing', data.bookmarks.length, 'bookmarks');

        fetch(getApiUrl('SAVE_ALL_BOOKMARKS'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ uid, bookmarks: data.bookmarks }),
        })
          .then((response) => {
            if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
          })
          .then((result) => {
            console.log('✅ All bookmarks synced successfully:', result);
          })
          .catch((error) => {
            console.error('❌ Bulk sync failed:', error);
          });
      } else {
        console.log('No bookmarks to sync');
      }
    });
  }

  // Update sync button text and icon
  function updateSyncButtonText() {
    chrome.storage.local.get(['uid', 'username'], (result) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error getting user data for button update:',
          chrome.runtime.lastError
        );
        return;
      }

      const isConnected = result.uid && result.username;
      console.log('Updating sync button, connected:', isConnected);

      const syncIcon = syncBtn.querySelector('.sync-icon svg');
      const syncText = syncBtn.querySelector('.sync-text');

      if (isConnected) {
        syncBtn.classList.add('connected');
        syncIcon.innerHTML = `
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
          <polyline points="15,3 21,3 21,9"/>
          <line x1="10" y1="14" x2="21" y2="3"/>
        `;
        syncText.textContent = 'Open in Dockly';

        // Add username display
        if (!syncBtn.querySelector('.sync-username')) {
          const usernameSpan = document.createElement('span');
          usernameSpan.className = 'sync-username';
          usernameSpan.textContent = `@${result.username}`;
          syncBtn.querySelector('.sync-content').appendChild(usernameSpan);
        }
      } else {
        syncBtn.classList.remove('connected');
        syncIcon.innerHTML = `
          <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9c2.35 0 4.48.9 6.07 2.38l1.43-1.43"/>
          <path d="M17 8l4-4-4-4"/>
        `;
        syncText.textContent = 'Sync to Dockly';

        // Remove username if exists
        const usernameEl = syncBtn.querySelector('.sync-username');
        if (usernameEl) {
          usernameEl.remove();
        }
      }
    });
  }

  // Modal functions
  function showModal() {
    modal.style.display = 'flex';
    setTimeout(() => {
      modal.classList.add('modal-open');
      usernameInput.focus();
    }, 10);
  }

  function closeModal() {
    modal.classList.remove('modal-open');
    setTimeout(() => {
      modal.style.display = 'none';
      clearError();
      usernameInput.value = '';
    }, 300);
  }

  // Loading state
  function showLoading(isLoading) {
    const submitBtn = loginForm.querySelector('button[type="submit"]');
    if (isLoading) {
      submitBtn.disabled = true;
      submitBtn.classList.add('loading');
      submitBtn.innerHTML = `
        <svg class="button-icon spinning" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 12a9 9 0 11-6.219-8.56"/>
        </svg>
        Connecting...
      `;
    } else {
      submitBtn.disabled = false;
      submitBtn.classList.remove('loading');
      submitBtn.innerHTML = `
        <svg class="button-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
          <polyline points="10,17 15,12 10,7"/>
          <line x1="15" y1="12" x2="3" y2="12"/>
        </svg>
        Connect & Sync
      `;
    }
  }

  // Error handling
  function showError(message) {
    console.error('Showing error:', message);
    errorEl.textContent = message;
    errorEl.style.display = 'block';
    errorEl.classList.add('error-show');
  }

  function clearError() {
    errorEl.textContent = '';
    errorEl.style.display = 'none';
    errorEl.classList.remove('error-show');
  }

  // Initialize the extension
  init();
});
