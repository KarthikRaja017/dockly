// Modern background service worker for Dockly Smart Bookmarks
const CONFIG = {
  PRIMARY_COLOR: '#0033FF',
  API_BASE_URL: 'http://127.0.0.1:5000/server/api',
  ENDPOINTS: {
    SAVE_BOOKMARK: '/bookmarks/save',
    SAVE_ALL_BOOKMARKS: '/bookmarks/all/save',
    ADD_USER: '/user/add/username',
  },
  BLOCKED_PROTOCOLS: ['chrome:', 'edge:', 'about:', 'file:'],
};

// Install event - Initialize extension
chrome.runtime.onInstalled.addListener((details) => {
  // Initialize storage with empty bookmarks array
  chrome.storage.local.set({ bookmarks: [] });

  console.log('🔖 Dockly Smart Bookmarks installed successfully!');

  // Show welcome notification on install (not update)
  if (details.reason === 'install') {
    chrome.notifications?.create({
      type: 'basic',
      iconUrl: 'icons/icon-48.png',
      title: 'Dockly Smart Bookmarks',
      message: 'Extension installed! Start bookmarking your favorite pages.',
    });
  }
});

// Handle messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);

  switch (message.action) {
    case 'setUID':
      // Store user ID from content script
      chrome.storage.local.set({ uid: message.uid }, () => {
        if (chrome.runtime.lastError) {
          console.error('Error setting UID:', chrome.runtime.lastError);
        } else {
          console.log('UID set from content script:', message.uid);
        }
      });
      break;

    case 'getBookmarks':
      // Return bookmarks to requesting script
      chrome.storage.local.get({ bookmarks: [] }, (data) => {
        if (chrome.runtime.lastError) {
          console.error('Error getting bookmarks:', chrome.runtime.lastError);
          sendResponse({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ bookmarks: data.bookmarks });
        }
      });
      return true; // Keep message channel open for async response

    case 'saveBookmark':
      // Save single bookmark
      handleSaveBookmark(message.bookmark, sendResponse);
      return true;

    case 'syncBookmarks':
      // Sync bookmarks to server
      handleSyncBookmarks(message.uid, sendResponse);
      return true;

    default:
      console.warn('Unknown message action:', message.action);
  }
});

// Handle saving a single bookmark
async function handleSaveBookmark(bookmark, sendResponse) {
  try {
    const result = await chrome.storage.local.get({ bookmarks: [] });
    const bookmarks = result.bookmarks;

    // Check if bookmark already exists
    const exists = bookmarks.some((b) => b.url === bookmark.url);

    if (!exists) {
      bookmarks.push({
        ...bookmark,
        timestamp: Date.now(),
      });

      await chrome.storage.local.set({ bookmarks });
      console.log('Bookmark saved:', bookmark.title);
    }

    sendResponse({ success: true, exists });
  } catch (error) {
    console.error('Error saving bookmark:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle syncing bookmarks to server
async function handleSyncBookmarks(uid, sendResponse) {
  try {
    const result = await chrome.storage.local.get({ bookmarks: [] });

    if (!uid) {
      throw new Error('User ID not provided');
    }

    if (result.bookmarks.length === 0) {
      sendResponse({ success: true, message: 'No bookmarks to sync' });
      return;
    }

    // Sync to server
    const response = await fetch(
      `${CONFIG.API_BASE_URL}${CONFIG.ENDPOINTS.SAVE_ALL_BOOKMARKS}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid,
          bookmarks: result.bookmarks,
        }),
      }
    );

    const data = await response.json();

    if (response.ok) {
      console.log('Bookmarks synced successfully:', data);
      sendResponse({ success: true, data });
    } else {
      throw new Error(data.message || 'Sync failed');
    }
  } catch (error) {
    console.error('Error syncing bookmarks:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle tab updates to potentially auto-bookmark
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Only process when page is completely loaded
  if (changeInfo.status === 'complete' && tab.url) {
    // Skip chrome:// and other system URLs
    if (
      CONFIG.BLOCKED_PROTOCOLS.some((protocol) => tab.url.startsWith(protocol))
    ) {
      return;
    }

    console.log('Page loaded:', tab.title);
  }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  // This should not trigger since we have a popup defined
  // But keeping it as fallback
  console.log('Extension icon clicked on:', tab.url);
});

// Cleanup on startup
chrome.runtime.onStartup.addListener(() => {
  console.log('🚀 Dockly Smart Bookmarks service worker started');
});

// Handle extension suspend
chrome.runtime.onSuspend.addListener(() => {
  console.log('💤 Dockly Smart Bookmarks service worker suspended');
});
